import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import ClientLayout from '../../ClientLayout';

const FONT    = "'Plus Jakarta Sans', system-ui, sans-serif";
const PRIMARY = '#166534';

const CARD = { backgroundColor: '#ffffff', borderRadius: '16px', border: 'none', boxShadow: '0 2px 16px rgba(0,0,0,0.07)', padding: '24px', marginBottom: '16px' };

function SectionHeader({ title, subtitle }) {
  return (
    <div style={{ marginBottom: '20px' }}>
      <h1 style={{ margin: '0 0 4px', fontSize: '22px', fontWeight: '700', color: '#0d1117', fontFamily: FONT }}>{title}</h1>
      {subtitle && <p style={{ margin: 0, fontSize: '13px', color: '#9ca3af', fontFamily: FONT }}>{subtitle}</p>}
    </div>
  );
}

function SettingsCard({ title, children }) {
  return (
    <div style={CARD}>
      {title && <p style={{ margin: '0 0 16px', fontSize: '14px', fontWeight: '600', color: '#0d1117', fontFamily: FONT }}>{title}</p>}
      {children}
    </div>
  );
}

function SaveButton({ onClick, saveMsg }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: '12px', marginTop: '8px' }}>
      {saveMsg && <span style={{ fontSize: '13px', color: '#16a34a', fontWeight: '600', fontFamily: FONT }}>{saveMsg}</span>}
      <button type="button" onClick={onClick}
        style={{ backgroundColor: PRIMARY, color: '#fff', border: 'none', borderRadius: '10px', padding: '9px 22px', fontSize: '13.5px', fontWeight: '600', cursor: 'pointer', fontFamily: FONT }}>
        Save
      </button>
    </div>
  );
}

function FieldRow({ label, children }) {
  return (
    <div style={{ marginBottom: '14px' }}>
      <label style={{ display: 'block', fontSize: '12px', fontWeight: '600', color: '#374151', marginBottom: '6px', fontFamily: FONT }}>{label}</label>
      {children}
    </div>
  );
}

function TextInput({ value, onChange, placeholder = '' }) {
  return (
    <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={{ width: '100%', boxSizing: 'border-box', border: '1px solid #d1d5db', borderRadius: '10px', padding: '9px 14px', fontSize: '13.5px', color: '#0d1117', outline: 'none', fontFamily: FONT, backgroundColor: '#fff' }} />
  );
}

function Textarea({ value, onChange, placeholder = '' }) {
  return (
    <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} rows={5}
      style={{ width: '100%', boxSizing: 'border-box', minHeight: '100px', border: '1px solid #d1d5db', borderRadius: '10px', padding: '12px 14px', fontSize: '13.5px', color: '#0d1117', fontFamily: FONT, resize: 'vertical', outline: 'none', backgroundColor: '#fff' }} />
  );
}

function useSaveMsg() {
  const [saveMsg, setSaveMsg] = useState('');
  function flash() { setSaveMsg('Saved!'); setTimeout(() => setSaveMsg(''), 2000); }
  return [saveMsg, flash];
}

function PDFContent({ clientId }) {
  const [loading,       setLoading]       = useState(true);
  const [companyName,   setCompanyName]   = useState('Your Company');
  const [previewColor,  setPreviewColor]  = useState(PRIMARY);
  const [intro,         setIntro]         = useState('');
  const [systemDesc,    setSystemDesc]    = useState('');
  const [serviceAg,     setServiceAg]     = useState('');
  const [payTerms,      setPayTerms]      = useState('');
  const [legal,         setLegal]         = useState('');
  const [sigName,       setSigName]       = useState('');
  const [sigTitle,      setSigTitle]      = useState('');
  const [sigPhone,      setSigPhone]      = useState('');
  const [sigEmail,      setSigEmail]      = useState('');
  const [saveMsg, flash] = useSaveMsg();
  const [lastSavedPdf, setLastSavedPdf] = useState(() => localStorage.getItem('qq360_last_saved_pdf') || '');
  const [sectionVisible, setSectionVisible] = useState({ intro: true, systemDesc: true, serviceAg: true, payTerms: true, legal: true });

  useEffect(() => {
    if (!clientId) return;
    supabase.from('client_settings').select('pdf_content, branding').eq('client_id', clientId).maybeSingle()
      .then(({ data }) => {
        const pc = data?.pdf_content || {};
        const b  = data?.branding   || {};
        setCompanyName(b.company_name   || 'Your Company');
        setPreviewColor(b.primary_color || PRIMARY);
        setIntro(pc.introduction       || '');
        setSystemDesc(pc.system_description || '');
        setServiceAg(pc.service_agreement  || '');
        setPayTerms(pc.payment_terms      || '');
        setLegal(pc.legal_reservations || '');
        setSigName(pc.signature_name     || '');
        setSigTitle(pc.signature_title    || '');
        setSigPhone(pc.signature_phone    || '');
        setSigEmail(pc.signature_email    || '');
        setLoading(false);
      });
  }, [clientId]);

  if (loading) return (
    <>
      <style>{`@keyframes pulse { 0%, 100% { opacity: 0.6; } 50% { opacity: 1; } }`}</style>
      {[0, 1, 2].map(i => (
        <div key={i} style={{ backgroundColor: '#ffffff', borderRadius: '16px', boxShadow: '0 2px 16px rgba(0,0,0,0.07)', padding: '24px', marginBottom: '16px' }}>
          <div style={{ height: '16px', borderRadius: '6px', backgroundColor: '#f0f0f0', marginBottom: '12px', width: '60%', animation: 'pulse 1.5s ease-in-out infinite' }} />
          <div style={{ height: '12px', borderRadius: '6px', backgroundColor: '#f0f0f0', marginBottom: '12px', width: '80%', animation: 'pulse 1.5s ease-in-out infinite' }} />
          <div style={{ height: '12px', borderRadius: '6px', backgroundColor: '#f0f0f0', marginBottom: '12px', width: '40%', animation: 'pulse 1.5s ease-in-out infinite' }} />
        </div>
      ))}
    </>
  );

  async function handleSave() {
    await supabase.from('client_settings').update({
      pdf_content: {
        introduction:       intro,
        system_description: systemDesc,
        service_agreement:  serviceAg,
        payment_terms:      payTerms,
        legal_reservations: legal,
        signature_name:     sigName,
        signature_title:    sigTitle,
        signature_phone:    sigPhone,
        signature_email:    sigEmail,
      },
    }).eq('client_id', clientId);
    flash();
    const ts = new Date().toISOString();
    localStorage.setItem('qq360_last_saved_pdf', ts);
    setLastSavedPdf(ts);
  }

  return (
    <div style={{ display: 'flex', gap: '24px', alignItems: 'flex-start' }}>
      {/* Left column: form */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <SectionHeader title="PDF Content" subtitle="Edit the text sections of your generated PDF." />
        {[
          { label: 'Introduction Text',  value: intro,      onChange: setIntro      },
          { label: 'System Description', value: systemDesc, onChange: setSystemDesc },
          { label: 'Service Agreement',  value: serviceAg,  onChange: setServiceAg  },
          { label: 'Payment Terms',      value: payTerms,   onChange: setPayTerms   },
          { label: 'Legal Reservations', value: legal,      onChange: setLegal      },
        ].map(s => (
          <SettingsCard key={s.label} title={s.label}><Textarea value={s.value} onChange={s.onChange} /></SettingsCard>
        ))}
        <SettingsCard title="Signature Block">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <FieldRow label="Name"> <TextInput value={sigName}  onChange={setSigName}  /></FieldRow>
            <FieldRow label="Title"><TextInput value={sigTitle} onChange={setSigTitle} /></FieldRow>
            <FieldRow label="Phone"><TextInput value={sigPhone} onChange={setSigPhone} /></FieldRow>
            <FieldRow label="Email"><TextInput value={sigEmail} onChange={setSigEmail} /></FieldRow>
          </div>
        </SettingsCard>
        <SaveButton onClick={handleSave} saveMsg={saveMsg} />
        {lastSavedPdf && <p style={{ margin: '6px 0 0', fontSize: '11px', color: '#9ca3af', fontFamily: FONT, textAlign: 'right' }}>Last saved: {(() => { const d = new Date(lastSavedPdf); return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; })()}</p>}
      </div>

      {/* Right column: preview */}
      <div style={{ width: '340px', flexShrink: 0, position: 'sticky', top: '80px' }}>
        <p style={{ margin: '0 0 10px', fontSize: '11px', fontWeight: '600', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', fontFamily: FONT }}>PDF Preview</p>

        <div style={{ backgroundColor: '#fff', borderRadius: '12px', padding: '24px', boxShadow: '0 2px 16px rgba(0,0,0,0.07)', fontSize: '12px', fontFamily: FONT }}>
          {/* Header */}
          <div style={{ backgroundColor: previewColor, borderRadius: '8px', padding: '14px 16px', marginBottom: '20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '14px', fontWeight: '700', color: '#fff' }}>{companyName}</span>
            <span style={{ fontSize: '11px', color: 'rgba(255,255,255,0.7)' }}>QUOTE</span>
          </div>
          {/* Customer */}
          <div style={{ marginBottom: '16px', paddingBottom: '16px', borderBottom: '1px solid #f4f6f4' }}>
            <p style={{ margin: '0 0 2px', fontSize: '10px', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Prepared for</p>
            <p style={{ margin: '0 0 1px', fontSize: '13px', fontWeight: '700', color: '#0d1117' }}>Customer Name</p>
            <p style={{ margin: 0, fontSize: '11px', color: '#9ca3af' }}>customer@example.com</p>
          </div>
          {/* Introduction */}
          {sectionVisible.intro && (
            <div style={{ marginBottom: '16px', paddingBottom: '16px', borderBottom: '1px solid #f4f6f4' }}>
              <p style={{ margin: '0 0 6px', fontSize: '10px', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Introduction</p>
              <p style={{ margin: 0, fontSize: '11px', color: '#374151', lineHeight: '1.6', whiteSpace: 'pre-wrap' }}>
                {intro || 'Your introduction text will appear here…'}
              </p>
            </div>
          )}
          {/* Footer */}
          <div style={{ paddingTop: '12px', borderTop: '1px solid #f4f6f4' }}>
            <p style={{ margin: '0 0 2px', fontSize: '11px', fontWeight: '600', color: '#0d1117' }}>{sigName || 'Signature Name'}</p>
            <p style={{ margin: '0 0 1px', fontSize: '10px', color: '#9ca3af' }}>{sigTitle || 'Title'}</p>
            <p style={{ margin: 0, fontSize: '10px', color: '#9ca3af' }}>{sigEmail || 'email@company.com'}</p>
          </div>
        </div>

        {/* Section Visibility Toggles */}
        <div style={{ marginTop: '16px' }}>
          <p style={{ margin: '0 0 10px', fontSize: '11px', fontWeight: '600', color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', fontFamily: FONT }}>Preview Options</p>
          <div style={{ backgroundColor: '#fff', borderRadius: '12px', padding: '16px', boxShadow: '0 2px 16px rgba(0,0,0,0.07)' }}>
            {[
              { key: 'intro',      label: 'Introduction'      },
              { key: 'systemDesc', label: 'System Description' },
              { key: 'serviceAg',  label: 'Service Agreement'  },
              { key: 'payTerms',   label: 'Payment Terms'      },
              { key: 'legal',      label: 'Legal Reservations' },
            ].map(({ key, label }, i, arr) => (
              <div key={key} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 0', borderBottom: i < arr.length - 1 ? '1px solid #f4f6f4' : 'none' }}>
                <span style={{ fontSize: '12px', color: '#374151', fontFamily: FONT }}>{label}</span>
                <div onClick={() => setSectionVisible(prev => ({ ...prev, [key]: !prev[key] }))}
                  style={{ width: '36px', height: '20px', borderRadius: '10px', backgroundColor: sectionVisible[key] ? PRIMARY : '#e5e7eb', position: 'relative', cursor: 'pointer', flexShrink: 0, transition: 'background-color 0.2s' }}>
                  <div style={{ width: '14px', height: '14px', borderRadius: '50%', backgroundColor: '#fff', position: 'absolute', top: '3px', left: sectionVisible[key] ? '19px' : '3px', transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfigStatusCard() {
  const { profile } = useAuth();
  const clientId = profile?.client_id;
  const [dots, setDots] = useState([
    !!localStorage.getItem('qq360_last_saved_branding'),
    !!localStorage.getItem('qq360_last_saved_pricing'),
    !!localStorage.getItem('qq360_last_saved_pdf'),
    !!localStorage.getItem('qq360_last_saved_municipalities'),
    !!localStorage.getItem('qq360_last_saved_questions'),
  ]);

  useEffect(() => {
    if (!clientId) return;
    Promise.all([
      supabase.from('client_settings').select('branding, pdf_content').eq('client_id', clientId).maybeSingle(),
      supabase.from('client_pricing').select('base_prices').eq('client_id', clientId).maybeSingle(),
      supabase.from('client_municipalities').select('id').eq('client_id', clientId).limit(1),
      supabase.from('client_questions').select('label_en').eq('client_id', clientId),
    ]).then(([{ data: s }, { data: p }, { data: m }, { data: q }]) => {
      setDots([
        !!(s?.branding?.company_name),
        !!(p?.base_prices && Object.values(p.base_prices).some(r => typeof r === 'object' && Object.values(r).some(v => Number(v) > 0))),
        !!(s?.pdf_content?.introduction),
        (m || []).length > 0,
        (q || []).some(x => x.label_en?.trim()),
      ]);
    }).catch(() => {});
  }, [clientId]);

  const navigate = useNavigate();
  const labels = ['Brand', 'Pricing', 'PDF', 'Areas', 'Questions'];
  const destinations = ['/client/settings', '/client/pricing', '/client/pdf', '/client/municipalities', '/client/questions'];
  const count = dots.filter(Boolean).length;
  const firstUndone = dots.findIndex(d => !d);
  return (
    <div style={{ ...CARD, padding: '16px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
      <div style={{ display: 'flex', gap: '16px' }}>
        {labels.map((label, i) => (
          <div key={label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: dots[i] ? '#16a34a' : '#e5e7eb' }} />
            <span style={{ fontSize: '10px', color: '#9ca3af', fontFamily: FONT }}>{label}</span>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <span style={{ fontSize: '13px', color: '#374151', fontFamily: FONT }}>{count} of 5 sections configured</span>
        {count < 5 ? (
          <button type="button" onClick={() => navigate(destinations[firstUndone])}
            style={{ backgroundColor: PRIMARY, color: '#fff', border: 'none', borderRadius: '10px', padding: '8px 18px', fontSize: '13px', fontWeight: '600', cursor: 'pointer', fontFamily: FONT, whiteSpace: 'nowrap' }}>
            Complete Setup →
          </button>
        ) : (
          <span style={{ color: '#16a34a', fontWeight: '600', fontSize: '13px', fontFamily: FONT }}>✓ All set!</span>
        )}
      </div>
    </div>
  );
}

export default function PdfContent() {
  const { profile } = useAuth();
  const clientId    = profile?.client_id;

  return (
    <ClientLayout title="PDF Content">
      <ConfigStatusCard />
      <PDFContent clientId={clientId} />
    </ClientLayout>
  );
}
